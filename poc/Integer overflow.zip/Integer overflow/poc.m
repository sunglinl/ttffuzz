#import <CoreText/CoreText.h>
#import <Cocoa/Cocoa.h>
#include <Foundation/Foundation.h>
int main(int argc, char** argv) 
{
    if (argc < 2) {
        NSLog(@"Usage: %s input is NULL\n", argv[0]);
        return 0;
    }
    NSString *replacementStartString = @"caonim fuck";
    int count = [replacementStartString length];
    CGFloat fontSize = 20;
    FILE *f = fopen(argv[1], "rb");
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* font_data = (char*)malloc(fsize);
    fread(font_data, fsize, 1, f);
    fclose(f);
    CGDataProviderRef fontDataProvider = CGDataProviderCreateWithData(NULL, font_data, fsize, NULL);
    if(fontDataProvider == NULL)
    {
        return 0;
    }
    CGFontRef fontRef = CGFontCreateWithDataProvider(fontDataProvider);
    CTFontRef font = CTFontCreateWithGraphicsFont(fontRef, fontSize, NULL, NULL);
    CFMutableAttributedStringRef attributeRef = CFAttributedStringCreateMutable(kCFAllocatorDefault, 0);
    CFAttributedStringReplaceString(attributeRef, CFRangeMake(0, 0), (CFStringRef)replacementStartString);
    CFAttributedStringSetAttribute(attributeRef, CFRangeMake(0, count), kCTFontAttributeName,font);
    CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString(attributeRef);
    free(font_data);
    CFRelease(font);
    CFRelease(framesetter);
    CFRelease(attributeRef);
    CFRelease(fontRef);


    return 1;
}