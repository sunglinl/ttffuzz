#import <CoreText/CoreText.h>
#import <Cocoa/Cocoa.h>
#include <Foundation/Foundation.h>
int main(int argc, char** argv) 
{
    if (argc < 2) {
        NSLog(@"Usage: %s input is NULL\n", argv[0]);
        return 0;
    }
    NSURL* fontUrl = [NSURL fileURLWithPath:[NSString stringWithUTF8String:argv[1]]];
    CGDataProviderRef fontDataProvider = CGDataProviderCreateWithURL((__bridge CFURLRef)fontUrl);
    CGFloat fontSize = 20;
    if(fontDataProvider == NULL)
    {
        return 0;
    }
    CGFontRef fontRef = CGFontCreateWithDataProvider(fontDataProvider);
  
    CTFontRef font = CTFontCreateWithGraphicsFont(fontRef, fontSize, NULL, NULL);

    CFStringRef keys[] = { kCTFontAttributeName }; 
    CFTypeRef values[] = { font }; 
    CFDictionaryRef attributeRef = CFDictionaryCreate(NULL, (const void **)&keys, 
    (const void **)&values, sizeof(keys) / sizeof(keys[0]), 
    &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks); 
    CFAttributedStringRef attributedString = CFAttributedStringCreate(NULL, CFSTR("fuck"), attributeRef); 
    CTLineRef line = CTLineCreateWithAttributedString(attributedString);

    CFRelease(font);
    CFRelease(fontDataProvider);
    CFRelease(line);
    CFRelease(attributeRef);
    CFRelease(fontRef);
    CFRelease(attributedString);


    return 1;
}