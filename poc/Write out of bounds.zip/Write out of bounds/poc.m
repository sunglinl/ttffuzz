#import <CoreText/CoreText.h>
#import <Cocoa/Cocoa.h>
#include <Foundation/Foundation.h>
int main(int argc, char** argv) 
{
    if (argc < 2) {
        NSLog(@"Usage: %s input is NULL\n", argv[0]);
        return 0;
    }
    NSString *replacementStartString = @"test wwww";
    int count = [replacementStartString length];
    NSURL* fontUrl = [NSURL fileURLWithPath:[NSString stringWithUTF8String:argv[1]]];
    CGFloat fontSize = 20;
    CGDataProviderRef fontDataProvider = CGDataProviderCreateWithURL((__bridge CFURLRef)fontUrl);
    if(fontDataProvider == NULL)
    {
        return 0;
    }
    CGFontRef fontRef = CGFontCreateWithDataProvider(fontDataProvider);

    CTFontRef font = CTFontCreateWithGraphicsFont(fontRef, fontSize, NULL, NULL);
    CFMutableAttributedStringRef attributeRef = CFAttributedStringCreateMutable(kCFAllocatorDefault, 0);
    CFAttributedStringReplaceString(attributeRef, CFRangeMake(0, 0), (CFStringRef)replacementStartString);
    CFAttributedStringSetAttribute(attributeRef, CFRangeMake(0, CFAttributedStringGetLength(attributeRef)), kCTFontAttributeName,font);
   // printf("attributeRef is %s\n", attributeRef->string);
    CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString(attributeRef);
    CFRelease(font);
    CFRelease(framesetter);
    CFRelease(attributeRef);
    CFRelease(fontRef);


    return 1;
}